import React from 'react'

function Home() {
    return (
        <div>
           <h1 className="heading" >Computer Science & Engineering</h1>
           <h2 className="heading">Welcome Back</h2>
        </div>
    )
}

export default Home;
