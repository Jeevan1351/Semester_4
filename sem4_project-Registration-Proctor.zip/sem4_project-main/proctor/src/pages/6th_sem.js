import React from "react";
import {Table} from '../components/Navbar';
const six_sem = () => {
  return (
    <div className="home">
      <h1 className="heading" >Computer Science & Engineering</h1>
        <h2 className="heading">VI Semester</h2>
        <Table/>
    </div>
  );
};
  
export default six_sem;