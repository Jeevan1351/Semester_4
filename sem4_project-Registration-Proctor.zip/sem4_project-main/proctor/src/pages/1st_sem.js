import React from "react";
import {Table} from '../components/Navbar';


 const fir_sem = () => {

  return (
    <div >
       <h1 className="heading" >Computer Science & Engineering</h1>
        <h2 className="heading">I Semester</h2>
        <Table />
     </div>
  );
};

export default fir_sem;