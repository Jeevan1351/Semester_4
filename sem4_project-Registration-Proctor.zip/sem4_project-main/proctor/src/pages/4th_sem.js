import React from "react";
import {Table }from '../components/Navbar';
const fort_sem = () => {
  return (
    <div className="home">
      <h1 className="heading" >Computer Science & Engineering</h1>
        <h2 className="heading">IV Semester</h2>
        <Table/>
    </div>
  );
};
  
export default fort_sem;